#!/bin/bash

echo "im the install script" >>/tmp/install_from_brew
